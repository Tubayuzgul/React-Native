import {  StyleSheet,  View,  Text, ScrollView, ActivityIndicator, FlatList } from 'react-native';
import { useState, useEffect } from 'react';
import {  backgroundColor,  StatusBarHeight,  paddingSpace} from '../utils/theme';
import { userGetData } from '../utils/storage';
import { allProduct } from '../utils/service';
import { Toast } from 'toastify-react-native';
import { IProduct } from '../models/IProducts';
import ProductItem from '../components/ProductItem';

export default function Product(){

const [load,setLoad]= useState(true)


  const [arr, setArr] = useState<IProduct[]>([])

 useEffect(()=> {
    setLoad(true)
    allProduct().then(res => {
      setArr(res.data.products)
    }).catch(err => {
      Toast.error("Product List Fail")
    }).finally(() => {
       setLoad(false)
    })
  }, [])


 useEffect(()=> {
 console.log("Product Call")
 userGetData().then(res=>{
   //console.log(res)
 })
 },[])

  return (
    <View style={styles.container}>
    {load && 
    <ActivityIndicator size='large' animating={load} hidesWhenStopped={!load}/>
    }
    {!load && 
      <FlatList 
        data={arr}
        renderItem={({item}) => <ProductItem item={item} /> }
        keyExtractor={(item)=> item.id.toString()}
      />
    }
    </View>
  )

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: backgroundColor,
    paddingTop: paddingSpace,
    paddingLeft: paddingSpace,
    paddingRight: paddingSpace,
    paddingBottom: paddingSpace,
  
  },

});
