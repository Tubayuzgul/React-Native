import {  StyleSheet,  View,  Text,  TextInput,  ScrollView,  TouchableOpacity, Alert, Image } from 'react-native';
import { useState } from 'react';
import {  backgroundColor,  StatusBarHeight,  paddingSpace,  titleColor,  inputStyle,  btnText,  btnView,} from '../utils/theme';
import Backbtn from '../components/BackBtn'

export default function Register() {

  //State Create
  const [userName, setUserName] = useState('') //ilk değer ataması boş
  const [password, setPassword] = useState('')

  //2. yol fonksiyon tanımlama örneği
  function send() {}


 const fncRegister =()=> {
 console.log('fncRegister call');
 }

  return (
    <ScrollView style={styles.container}>
   
    <Backbtn iconColor={''}/>
    <Image style={{width:60, height:60,  alignSelf:'center', marginBottom:20}} source={require('../assets/logo.png')}/>
      <Text style={styles.title}>User Register</Text>
      <TextInput onChangeText={(txt:string)=> setUserName(txt)}  placeholder="User Name" keyboardType="email-address"   style={inputStyle} autoCapitalize="none"   />  
      <TextInput onChangeText={(txt:string)=> setPassword(txt)}  placeholder="Password"   style={inputStyle}    secureTextEntry={true}   />
 <View style={{ flexDirection: 'row' , justifyContent: 'space-between' }}>
        <TouchableOpacity onPress={fncRegister}>
        <View style={btnView}>
          <Text style={[btnText, { color:titleColor}] }>Register</Text>
        </View>
      </TouchableOpacity>
</View>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: backgroundColor,
    paddingTop: StatusBarHeight,
    paddingLeft: paddingSpace,
    paddingRight: paddingSpace,
    paddingBottom: paddingSpace,
  
  },

  title: {
    textAlign: 'center',
    fontFamily: 'Arial',
    fontSize: 30,
    color: titleColor,
  },
});
