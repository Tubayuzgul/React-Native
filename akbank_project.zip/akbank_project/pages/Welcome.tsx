import {View, Text, StatusBar, StyleSheet, TouchableOpacity, Platform, Vibration } from 'react-native'
import Swiper from 'react-native-swiper'
import {useState,useEffect} from 'react'
import { SimpleLineIcons, Octicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { v4 as uuidv4 } from 'uuid';

export default function Welcome(){

const [index,setIndex] = useState(0)
const navigation = useNavigation()
console.log(Platform.OS)
console.log(uuidv4)

useEffect(()=>{
  if(index>0){
    if(Platform.OS==='ios'){
          Vibration.vibrate(1000)
    }
    else{
          Vibration.vibrate(500)
    }
  }
}, [index])

  return(
      <>
        <StatusBar hidden={true} />
        <Swiper
         style={styles.swipeContainer} 
         showsButtons={true}
         onIndexChanged={(index) => setIndex(index)}
         loadMinimalSize={3}
         loadMinimal={true}
         > 
            <View style={styles.box}>
              <SimpleLineIcons name="home" size={135} color={'#4287f5'} />
              <View style={{margin: 20}}>
              <TouchableOpacity onPress={() => navigation.replace("LoginStack")}>
                <View style={{ backgroundColor: '#e38b09', width: '100%', borderRadius: 10, padding: 10,   }}>
                  <Text style={{ textAlign: 'center', fontSize: 18, color: '#ffffff' }}>Goto</Text>
                </View>
              </TouchableOpacity>
              </View>
            </View>
             <View style={styles.box}>
              <SimpleLineIcons name="basket" size={135} color={'#4287f5'} />
            </View>
            <View style={styles.box}>
              <SimpleLineIcons name="like" size={135} color={'#4287f5'} />
            </View>
        </Swiper>
      </>
  )
}

const styles= StyleSheet.create({

swipeContainer:{

},

box:{
   flex:1,
   justifyContent: 'center',
   alignSelf: 'center'
}

})