import {  StyleSheet,  View,  Text, ScrollView, FlatList } from 'react-native'
import { useState, useEffect } from 'react';
import {  backgroundColor,  StatusBarHeight,  paddingSpace} from '../utils/theme';
import { userGetData } from '../utils/storage';
import {useSelector , useDispatch} from 'react-redux'
import {StateType} from '../useRedux/Store'
import ProductItem from '../components/ProductItem';
import BackBtn from '../components/BackBtn';

export default function Likes(){

//Obje dönecek 
const likesData= useSelector((obj: StateType) => obj.LikesReducer)
const dispatch = useDispatch()

useEffect(()=> {
 console.log("Likes Call")
 userGetData().then(res=>{
   //console.log(res)
 })
 },[])
 
  return (
    <View style={styles.container}>
      <FlatList 
        data={likesData}
        renderItem={({item}) => <ProductItem item={item} /> }
        keyExtractor={(item)=> item.id.toString()}
      />
    </View>
  )

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: backgroundColor,
    paddingTop: StatusBarHeight,
    paddingLeft: paddingSpace,
    paddingRight: paddingSpace,
    paddingBottom: paddingSpace,
  
  },

});
