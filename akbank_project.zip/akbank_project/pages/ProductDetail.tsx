import {Text, View, ScrollView , StyleSheet, Image,TouchableOpacity} from 'react-native';
import {useNavigation,useRoute}  from  '@react-navigation/native';
import {useEffect,useState} from 'react'
import { IProduct } from '../models/IProducts';
import BackBtn from '../components/BackBtn';
import {  backgroundColor,  StatusBarHeight,  paddingSpace,  titleColor,  inputStyle,  btnText,  btnView,} from '../utils/theme';
import { singleProduct } from '../utils/service';
import { AntDesign } from '@expo/vector-icons';
import {useSelector , useDispatch} from 'react-redux'
import {StateType} from '../useRedux/Store'
import { ILikeAction } from '../useRedux/LikesReducer';
import { LikesEnum } from '../useRedux/LikesEnum';

export default function ProductDetail(){

//Likes ekranına göndereceğimiz ürünü belirleyeceğiz.
const likesData= useSelector((obj: StateType) => obj.LikesReducer)
const dispatch = useDispatch()

const navigate= useNavigation()

//Servisten gelen response state aktaracağız.
const [proItem, setProItem] = useState<IProduct>()

const [bigImage, setBigImage] = useState('')
const [likeStatus, setlikeStatus] = useState(false)

// Data burada olacak, Data ProductItem dan gelecek. react native sayfasında örnek kullanım
const route = useRoute()

// servise gideceğiz, data değişmiş olabilir diye, singleProduct Service.tsx te, state responsu attık.
useEffect(()=>{
    if(route.params.item){
        const item= route.params.item as IProduct
        singleProduct(item.id).then(res=>{
          if(res.status===200){
            setBigImage(res.data.images[0])
            setProItem(res.data)  
            const index= likesData.findIndex((item)=>item.id===res.data.id)
            if(index>-1){
                setlikeStatus(true)
            }
          }
          else{
            navigate.goBack()
          }
        })
    }
},[])

const fncLikeStatus= () =>{
  if(!likeStatus){
    const obj: ILikeAction={
      type: LikesEnum.LIKE_ADD,
      payload:proItem!
    }
    dispatch(obj)
  }
  else{
 const obj: ILikeAction={
      type: LikesEnum.LIKE_REMOVE,
      payload:proItem!
    }
    dispatch(obj)
  }
setlikeStatus(!likeStatus)

}

  return(
    <ScrollView style={styles.container}>
    <BackBtn/>
          {proItem && 
           <View style={{marginTop:40}}> 
             <Text style={styles.title}> {proItem.title} </Text>
             <View style={{marginTop:10}}>
             <View> 
              <View style={{position:'absolute', right:10, top:10, zIndex:1}}>  
                   <TouchableOpacity onPress={fncLikeStatus}>
               <AntDesign name="heart" size={24} color={likeStatus===true ? "#369ff5": "red"} /> 
                 </TouchableOpacity> 
                </View>
              <Image source={{uri:bigImage}} style={{height:300, width:'100%'}}/>
              </View>
             <ScrollView horizontal  showsHorizontalScrollIndicator={false}> 
               <View style={{flexDirection: 'row' , justifyContent: 'space-between'}}>
                  {
                    proItem.images.map((item,index)=>
                    <TouchableOpacity key={index} onPress={()=>setBigImage(item)}>
                    <Image source={{uri:item}} style={{width:75, marginRight:5, height:100}}/>
                    </TouchableOpacity>
                    )}
               </View>
               </ScrollView>
             </View>
               <Text style={[styles.title, {color:'#369ff5', fontWeight:'bold' , textAlign:'right', fontSize:21, marginTop:10}]}>{proItem.price}₺</Text>
                <Text style={ { marginTop:10}}>{proItem.description}₺</Text>
           </View>
           }
    
    </ScrollView>

  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: backgroundColor,
    paddingTop: StatusBarHeight,
    paddingLeft: paddingSpace,
    paddingRight: paddingSpace,
    paddingBottom: paddingSpace,
  
  },
 title: {
    textAlign: 'center',
    fontFamily: 'Arial',
    fontSize: 30,
    color: titleColor,
  },
});

function usaState(): [any,any] {
throw new Error('Function not implemented.');
}
