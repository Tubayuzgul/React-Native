import {  StyleSheet,  View,  Text,  TextInput,  ScrollView,  TouchableOpacity, Alert, Image } from 'react-native';
import { useState, useEffect } from 'react';
import {  backgroundColor,  StatusBarHeight,  paddingSpace,  titleColor,  inputStyle,  btnText,  btnView,} from '../utils/theme';

import {useNavigation}  from  '@react-navigation/native';
import { userLogin } from '../utils/service';
import { Toast } from 'toastify-react-native';
import { likesGetData, userSetData } from '../utils/storage';
import { ILikeAction } from '../useRedux/LikesReducer';
import { LikesEnum } from '../useRedux/LikesEnum';
import {useDispatch} from 'react-redux'
import AsyncStorage from '@react-native-async-storage/async-storage'


export default function Login() {

const navigation = useNavigation()

//Default redux data
const dispatch= useDispatch()

useEffect(()=>{
 likesGetData().then(obj=>{
    if(obj){
    obj.forEach(item =>{
       const sendObj: ILikeAction={
        type:LikesEnum.LIKE_ADD,
        payload:item
       }
       dispatch(sendObj)
    })
  }
   })

},[])

  //State Create
  const [userName, setUserName] = useState('kminchelle') //ilk değer ataması boş
  const [password, setPassword] = useState('0lelplR')

  //2. yol fonksiyon tanımlama örneği
  function send() {}

//1.yol fonksiyon tanımalama
  const fncLogin = () => {
    if(userName ===''){
     Alert.alert("Fail", "Username Empty!")
    }
    else if(password ===''){
   Alert.alert("Fail", "Password Empty!")
    }
       else if(password.length <5){
 Alert.alert("Fail", "Password chars 5 Fail!")
       }
       else{
         userLogin(userName,password).then(async res =>{    
         if(res.status==200){
           //data  IJWTUserModel tipinde
         await userSetData(res.data)
         // navigation.navigate("Product")
          navigation.replace("AppTab")
         }
         }).catch(error => {
            console.log(error.message)
            Toast.error("User Name or Password Failerror")
         })
       }

  };

 const fncRegister =()=> {
  navigation.navigate("Register")
 }



  return (
    <ScrollView style={styles.container}>
  
    <Image style={{width:60, height:60,  alignSelf:'center', marginBottom:20}} source={require('../assets/logo.png')}/>
      <Text style={styles.title}> User Login </Text>
      <TextInput value={userName} onChangeText={(txt:string)=> setUserName(txt)}  placeholder="User Name" keyboardType="email-address"   style={inputStyle} autoCapitalize="none"   />  
      <TextInput value= {password} onChangeText={(txt:string)=> setPassword(txt)}  placeholder="Password"   style={inputStyle}    secureTextEntry={true}   />
 <View style={{ flexDirection: 'row' , justifyContent: 'space-between' }}>
      <TouchableOpacity onPress={fncLogin}>
        <View style={btnView}>
          <Text style={btnText}>Login</Text>
        </View>
      </TouchableOpacity>
        <TouchableOpacity onPress={fncRegister}>
        <View style={btnView}>
          <Text style={[btnText, { color:titleColor}] }>Register</Text>
        </View>
      </TouchableOpacity>
</View>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: backgroundColor,
    paddingTop: StatusBarHeight,
    paddingLeft: paddingSpace,
    paddingRight: paddingSpace,
    paddingBottom: paddingSpace,
  
  },

  title: {
    textAlign: 'center',
    fontFamily: 'Arial',
    fontSize: 30,
    color: titleColor,
  },
});
