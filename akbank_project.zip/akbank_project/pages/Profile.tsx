import {  StyleSheet,  View,  Text, ScrollView, TouchableOpacity,Button } from 'react-native';
import { useState, useEffect } from 'react';
import {  backgroundColor,  StatusBarHeight,  paddingSpace} from '../utils/theme';
import { userGetData } from '../utils/storage';
import { Hoshi } from 'react-native-textinput-effects';
import { IJWTUserModel } from '../models/IJWTuserModel';
import MapView, {Marker} from 'react-native-maps';
import { Camera, CameraType } from 'expo-camera';

export default function Profile(){
   // Giriş yapan kullanıcı bilgisini aldık
  const [user, setUser] = useState<IJWTUserModel>()
  useEffect(()=> {
     console.log("Profile Call")
     userGetData().then(res => {
      if (res) {
        setUser(res)
      }
    })
  }, [])

  //Kamera
  const [type, setType] = useState(CameraType.back);
  const [permission, requestPermission] = Camera.useCameraPermissions();

 function toggleCameraType() {
    setType(current => (current === CameraType.back ? CameraType.front : CameraType.back));
  }

 if (!permission) {
    // Camera permissions are still loading
    return <View />;
  }

  if (!permission.granted) {
    // Camera permissions are not granted yet
    return (
      <View style={styles.container}>
        <Text style={{ textAlign: 'center' }}>We need your permission to show the camera</Text>
        <Button onPress={requestPermission} title="grant permission" />
      </View>
    );
  }

 
  return (
    <ScrollView style={styles.container}>
     {user &&
       <>
       <Hoshi
          label={'Name'}
          borderColor={'#b76c94'}
          borderHeight={1}
          inputPadding={0}
          backgroundColor={'#F9F7F6'}
          style={{marginBottom: 15 }}
          inputStyle={{paddingTop: 15, fontSize: 15, paddingLeft:15}}
          labelStyle={{paddingLeft: 15}}
          defaultValue={user.firstName}
        />
        <Hoshi
          label={'Surname'}
          borderColor={'#b76c94'}
          borderHeight={1}
          inputPadding={0}
          backgroundColor={'#F9F7F6'}
          style={{marginBottom: 15}}
          inputStyle={{paddingTop: 15, fontSize: 15, paddingLeft:15}}
          labelStyle={{paddingLeft: 15}}
          defaultValue={user.lastName}
        />
        </>
      }
      <MapView
        style={{width: '100%', height: 300}}
        initialRegion={{
          latitude: 40.221678,
          longitude: 29.0322895,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421,
        }}
        >
        <Marker
        coordinate= {{latitude:40.221678, longitude:29.0322895}}
            title='İşletme -1'
        description='İşletme -1 Detay'
        />
       </MapView>
    
      
       <Camera style={{ width: '100%', height: 200 }} type={type}>
        <View style={{width: 100, height: 30, backgroundColor:'green'}}>
          <TouchableOpacity style={{}} onPress={toggleCameraType}>
            <Text style={{}}>Flip Camera</Text>
          </TouchableOpacity>
        </View>
      </Camera>

    </ScrollView>
  )

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: backgroundColor,
    paddingTop: StatusBarHeight,
    paddingLeft: paddingSpace,
    paddingRight: paddingSpace,
    paddingBottom: paddingSpace,
  },
});
