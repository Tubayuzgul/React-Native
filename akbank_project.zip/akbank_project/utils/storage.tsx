import AsyncStorage from '@react-native-async-storage/async-storage'
import {IJWTUserModel} from '../models/IJWTuserModel'
import { IProduct } from '../models/IProducts'

//Login olduktan sonra token bilgilerini buraya depolayacak. 
//asekron olduğu için fonksiyon başına await ekliyoruz. Beklesin diye. Tokeni yazdığından emin olmamız lazım.
//Login kodlarıda asekron olarak çalışır.
// Data IJWTUserModel model tipinde
// Datayı objeye çeviyor ama bunu xml dosyasına yazıyor arkada. O yüzden datayı obje olarak saklayamıyor.
export const userSetData= async (data:IJWTUserModel )=>{
const st= JSON.stringify(data)
await AsyncStorage.setItem('@user',st)
}

//Giriş yapan kullanııcın bilgilerini alıyoruz. Yaşayan session gibi.
//Örn: Kullanıcı giriş yaptı sipariş verecek kullanıcı bilgileri buradan alınacak.
//user dosyasını aç içini oku demek.
//Prodcut sayfasında kullandık
export const userGetData= async () =>{
  try{
     const stData = await AsyncStorage.getItem('@user')
     const userModel= JSON.parse(stData) as IJWTUserModel
    return userModel
  }catch(err){
    return null
  }
}

//Likes Store Data
export const likesSetData= async (data:IProduct[] )=>{
const st= JSON.stringify(data)
await AsyncStorage.setItem('@likes',st)
}

//Likes get data
export const likesGetData= async () =>{
  try{
     const jsonValue= await AsyncStorage.getItem('@likes')
     return jsonValue !=null? JSON.parse(jsonValue) as IProduct[]: null
  }catch(err){
     return null
  }
}
