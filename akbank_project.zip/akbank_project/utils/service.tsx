import axios from 'axios'
import { IJWTUserModel } from '../models/IJWTuserModel'
import { IProduct, IProducts } from '../models/IProducts'

const base_url= "https://dummyjson.com"

const config = axios.create({
  baseURL:base_url,
  timeout:15000,
  //headers:{ 'keytoken':'12345'},
 // auth:{username: '', password:''}
})


//Login User  , Login.tsx te kullandık
export const userLogin=(username:string, password:string)=>{
     const sendObj={
        username:username,
        password:password
  }
 return config.post<IJWTUserModel>('auth/login',sendObj)
}

// All Products
//https://dummyjson.com/products  şu adresse get yapmıştık olduk
export const allProduct = ()=>{
  return config.get<IProducts>('products')
}

//Single Product Number tipinde id parametresi alıyor.

export const singleProduct=(id:number) =>{
return config.get<IProduct>('products/'+id)
}