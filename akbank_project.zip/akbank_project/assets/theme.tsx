
import { getStatusBarHeight } from 'react-native-status-bar-height';  // react-native-status-bar-heigh  bu kütüphane içerisinden getStatusBarHeight metodunu çağırdık onuda constanta atadık. Constantı app.tsx içerisnde kullandık

export const backgroundColor= "white"
export const StatusBarHeight=getStatusBarHeight()
export const paddingSpace=10
export const titleColor="#1c67b8"

//input style

export const inputStyle= {
borderWidth:1,
padding:10,
borderColor:titleColor,
borderRadius:5,
fontSize:18,
marginBottom:10
}

// btn style
export const btnView={
borderRadius:5,
borderWidth:1,
padding:10,
borderColor:titleColor,
}

export const btnText={
fontSize:18,
textAlign: 'center' as 'center'
}
