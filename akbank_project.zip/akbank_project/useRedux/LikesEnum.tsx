export enum LikesEnum{
  LIKE_ADD = "LIKE_ADD",
  LIKE_REMOVE= "LIKE_REMOVE"
}