import { IProduct } from "../models/IProducts";
import { LikesEnum } from "../useRedux/LikesEnum";
import { likesGetData, likesSetData } from "../utils/storage";

//type kelimesini biz belirtiyoruz state ne için çalışması gerektiğini söyleyecek
export interface ILikeAction{
  type : LikesEnum,
  payload : IProduct
}


//State Iproduct tipinde olacak ve ilk değeri boş [] olacak
//...state -> state içinde ne varsa anlamında
//  const newArr= [...state,action.payload] => ...state -> state içinde ne varsa action.payload ile üzerine ekle
//state de her zaman en son hali bulunur.
//    const newArrX = Object.assign([],state)   --> onbeyi state assign et demek
export const LikesReducer= (state:IProduct[]=[], action:ILikeAction) =>{
  switch(action.type){
   
   case LikesEnum.LIKE_ADD:
   const newArr = [...state,action.payload]
   likesSetData(newArr)
   return newArr
  
   case LikesEnum.LIKE_REMOVE:
   const index = state.findIndex((item)=>item.id===action.payload.id)
   const newArrX = Object.assign([],state)
      if(index>-1){
        newArrX.splice(index,1)
        likesSetData(newArrX)
        return newArrX
      }
    return state
  
   default:
     return state
  }
}